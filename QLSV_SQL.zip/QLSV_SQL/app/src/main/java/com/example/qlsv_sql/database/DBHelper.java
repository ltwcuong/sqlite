package com.example.qlsv_sql.database;

import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import androidx.annotation.Nullable;

import com.example.qlsv_sql.mode.SinhVien;

public class DBHelper extends SQLiteOpenHelper {
    public DBHelper(@Nullable Context context) {
        super(context, "QuanliSinhVien.sqlite", null, 1);
    }

    @Override
    public void onCreate(SQLiteDatabase sqLiteDatabase) {
        String sqlSvCreate = "CREATE TABLE IF NOT EXISTS "
        +"Sinhvien(maSV_204 INTEGER PRIMARY KEY AUTOINCREMENT,"+
        "hoTen_204 VARCHAR(200),"+
        "gioiTinh_204 INTEGER,"+
        "sdt_204 VARCHAR(13),"+
        "email_204 VARCHAR(200))";
        sqLiteDatabase.execSQL(sqlSvCreate);
        String sqlinsert1 ="INSERT INTO Sinhvien(hoTen_204,gioiTinh_204,sdt_204,email_204) VALUES ('Cuong','0','098','thanhcuong@gmail.com')";
        String sqlinsert2 ="INSERT INTO Sinhvien(hoTen_204,gioiTinh_204,sdt_204,email_204) VALUES ('Cuong1','0','0982','thauong2@gmail.com')";
        String sqlinsert3 ="INSERT INTO Sinhvien(hoTen_204,gioiTinh_204,sdt_204,email_204) VALUES ('Cuong2','0','0981','thanuong1@gmail.com')";
        sqLiteDatabase.execSQL(sqlinsert1);
        sqLiteDatabase.execSQL(sqlinsert2);
        sqLiteDatabase.execSQL(sqlinsert3);

    }

    @Override
    public void onUpgrade(SQLiteDatabase sqLiteDatabase, int i, int i1) {

    }
}
