package com.example.qlsv_sql.dao;

import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;

import com.example.qlsv_sql.database.DBHelper;
import com.example.qlsv_sql.mode.SinhVien;

import java.util.ArrayList;
import java.util.List;

public class SinhVienDAO {
    private DBHelper csdl_204;
    public SinhVienDAO(Context context){
        csdl_204= new DBHelper(context);
    }
    public List<SinhVien> TatCaSinhVien(){
        String sql ="SELECT * FROM Sinhvien";
        List<SinhVien> sinhVienList = new ArrayList<SinhVien>();
        SQLiteDatabase database = csdl_204.getReadableDatabase();
        Cursor cursor = database.rawQuery(sql,null);
        cursor.moveToFirst();
        while (!cursor.isAfterLast()){
            int maSV = cursor.getInt(0);
            String hoTen = cursor.getString(1);
            int gioiTinh = cursor.getInt(2);
            String sdt =cursor.getString(3);
            String email = cursor.getString(4);
            SinhVien sv_204 = new SinhVien(maSV,hoTen,gioiTinh,sdt,email);
            sinhVienList.add(sv_204);
            cursor.moveToNext();


        }
        return sinhVienList;
    }



}
