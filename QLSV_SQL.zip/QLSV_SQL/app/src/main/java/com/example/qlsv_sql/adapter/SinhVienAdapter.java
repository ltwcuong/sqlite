package com.example.qlsv_sql.adapter;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.recyclerview.widget.RecyclerView;

import com.example.qlsv_sql.R;
import com.example.qlsv_sql.mode.SinhVien;

import java.util.List;

public class SinhVienAdapter extends BaseAdapter {
    private List<SinhVien> sinhVienList_204;
    private Context context_204;

    public SinhVienAdapter(Context context_204, List<SinhVien> listList_204){
        this.context_204=context_204;
        this.sinhVienList_204=listList_204;

    }


    @Override
    public int getCount() {
        return sinhVienList_204.size();
    }

    @Override
    public Object getItem(int i) {
        return null;
    }

    @Override
    public long getItemId(int i) {
        return 0;
    }

    @Override
    public View getView(int i, View view, ViewGroup viewGroup) {
        ViewHolder viewHolder;
        if(view==null){
            viewHolder = new ViewHolder();
            view.setTag(viewHolder);
            LayoutInflater inflater = (LayoutInflater) context_204.getSystemService(context_204.LAYOUT_INFLATER_SERVICE);
            view=inflater.inflate(R.layout.list_item_sinhvien,null);

            viewHolder.tvmaSV_204= view.findViewById(R.id.tv_masv);
            viewHolder.tvHoten_204 = view.findViewById(R.id.tv_hoten);
            viewHolder.tvdt_204 = view.findViewById(R.id.tv_dt);
            viewHolder.ivGioitinh_204 = view.findViewById(R.id.imGioitinh);
            viewHolder.tv_emain_204 = view.findViewById(R.id.tv_email);
        }else{

            viewHolder = (ViewHolder) view.getTag();

        }
        SinhVien sv_204 = sinhVienList_204.get(i);
        viewHolder.tvmaSV_204.setText("Ma sinh vien" + sv_204.getMaSV_204());
        viewHolder.tvHoten_204.setText("Ho ten sinh vien" + sv_204.getHoTen_204());
        viewHolder.tvdt_204.setText("So dien thoai sinh vien" + sv_204.getSdt_204());
        viewHolder.tv_emain_204.setText("Email sinh vien" + sv_204.getEmail_204());
        viewHolder.ivGioitinh_204.setImageResource(R.drawable.face);
        if (sv_204.getGioiTinh_204()==0){
            viewHolder.ivGioitinh_204.setImageResource(R.drawable.face1);
        }else{
            viewHolder.ivGioitinh_204.setImageResource(R.drawable.face);
        }
        return view;
    }
    private class ViewHolder
    {
        ImageView ivGioitinh_204;
        TextView tvmaSV_204,tvHoten_204,tvdt_204,tv_emain_204;

    }
}
