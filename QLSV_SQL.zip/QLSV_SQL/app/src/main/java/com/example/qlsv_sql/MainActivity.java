package com.example.qlsv_sql;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.ListView;

import com.example.qlsv_sql.adapter.SinhVienAdapter;
import com.example.qlsv_sql.dao.SinhVienDAO;
import com.example.qlsv_sql.mode.SinhVien;

import java.util.ArrayList;
import java.util.List;

public class MainActivity extends AppCompatActivity {
    private ListView lvsv_204;
    private List<SinhVien> sinhVienList_204;
    private SinhVienAdapter adapter;
    private SinhVienDAO svDAO_204;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        lvsv_204 =(ListView) findViewById(R.id.lv_SV);

        svDAO_204 = new SinhVienDAO(MainActivity.this);
        sinhVienList_204 = svDAO_204.TatCaSinhVien();
        adapter = new SinhVienAdapter(getApplicationContext(),sinhVienList_204);
        lvsv_204.setAdapter(adapter);

    }


    public boolean onCreateOptionsMenu(Menu menu){
        getMenuInflater().inflate(R.menu.menu,menu);
        return true;
    }

    public boolean onOptionsItemSelectd(MenuItem item){
        int id = item.getItemId();
        if(id== R.id.menuthem){
            Intent intent =  new Intent(MainActivity.this,AddActivity.class);
            startActivity(intent);
        }
        if(id== R.id.menuthoat){
           finish();
        }
        return true;
    }

}