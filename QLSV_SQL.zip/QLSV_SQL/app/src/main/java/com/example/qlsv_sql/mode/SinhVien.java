package com.example.qlsv_sql.mode;

public class SinhVien {
    private int maSV_204;
    private String hoTen_204;
    private int gioiTinh_204;
    private String sdt_204;
    private String email_204;

    public SinhVien(){

    }

    public SinhVien(int maSV_204, String hoTen_204, int gioiTinh_204, String sdt_204, String email_204) {
        this.maSV_204 = maSV_204;
        this.hoTen_204 = hoTen_204;
        this.gioiTinh_204 = gioiTinh_204;
        this.sdt_204 = sdt_204;
        this.email_204 = email_204;
    }

    public int getMaSV_204() {
        return maSV_204;
    }

    public void setMaSV_204(int maSV_204) {
        this.maSV_204 = maSV_204;
    }

    public String getHoTen_204() {
        return hoTen_204;
    }

    public void setHoTen_204(String hoTen_204) {
        this.hoTen_204 = hoTen_204;
    }

    public int getGioiTinh_204() {
        return gioiTinh_204;
    }

    public void setGioiTinh_204(int gioiTinh_204) {
        this.gioiTinh_204 = gioiTinh_204;
    }

    public String getSdt_204() {
        return sdt_204;
    }

    public void setSdt_204(String sdt_204) {
        this.sdt_204 = sdt_204;
    }

    public String getEmail_204() {
        return email_204;
    }

    public void setEmail_204(String email_204) {
        this.email_204 = email_204;
    }
}
